# ESC_avenger
50.003 Contact center routing for Rainbow communication platform.
1. A web page simulating customer's website where their users can request for
support via chat or audio call.
2. A routing engine that routes incoming chat and audio call requests to the right
agent based on agent availability, skills etc
