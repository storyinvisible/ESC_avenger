const userList = {
    "user1": {
        userEmail: "james@email.com",
        userPassword: "hfcI6236&$",
        userFirstname: "James",
        userLastname: "Lee"
    },

    "user2": {
        userEmail: "jenny@email.com",
        userPassword: "dDkwi29e&4",
        userFirstname: "Jenny",
        userLastname: "Ong"
    },

    "user3": {
        userEmail: "peter@email.com",
        userPassword: "sjdjwe8Gtf^",
        userFirstname: "Peter",
        userLastname: "Griffin"
    },

    "user4": {
        userEmail: "mary@email.com",
        userPassword: "ksdkY*734Yw",
        userFirstname: "Mary",
        userLastname: "Jane"
    }
}

const getALlEmails = () => {
    let email_list = [];
    for (let user in userList) {
        email_list.push(userList[user].userEmail);
    }
    return email_list;
}

module.exports = {
    userList,
    getALlEmails
}